import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';


import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { LoginIntComponent } from './LoginInt/LoginInt.component';
import { RegisterIntComponent } from './RegisterInt/RegisterInt.component';

import { ComponentssComponent } from './Componentss/Componentss.component';
import { InternerComponent } from './Componentss/Interner/Interner.component';
import { IntDesgComponent } from './Componentss/IntDesg/IntDesg.component';
import { DesgShowComponent } from './Componentss/IntDesg/desg-show/desg-show.component';
import { DesgAddEditComponent } from './Componentss/IntDesg/desg-add-edit/desg-add-edit.component';
import { IntAddEditComponent } from './Componentss/Interner/int-add-edit/int-add-edit.component';
import { IntShowComponent } from './Componentss/Interner/int-show/int-show.component';
import { SharedIntService } from './shared/sharedInt.service';
import { WorkIntHrComponent } from './Componentss/work-int-hr/work-int-hr.component';
import { HrAddEditComponent } from './Componentss/work-int-hr/hr-add-edit/hr-add-edit.component';
import { HrShowComponent } from './Componentss/work-int-hr/hr-show/hr-show.component';
import { RequestLeavComponent } from './Componentss/request-leav/request-leav.component';
import { LeavAddEditComponent } from './Componentss/request-leav/leav-add-edit/leav-add-edit.component';
import { LeavShowComponent } from './Componentss/request-leav/leav-show/leav-show.component';
import { StatusComponent } from './Componentss/status/status.component';
import { ShowStatComponent } from './Componentss/status/show-stat/show-stat.component';
import { AddEditStatComponent } from './Componentss/status/add-edit-stat/add-edit-stat.component';





@NgModule({
  declarations: [
    AppComponent,
      LoginIntComponent,
      RegisterIntComponent,
      InternerComponent,
      IntDesgComponent,
      DesgShowComponent,
      DesgAddEditComponent,
      IntAddEditComponent,
      IntShowComponent,

      WorkIntHrComponent,
      HrAddEditComponent,
      HrShowComponent,

      RequestLeavComponent,
      LeavAddEditComponent,
      LeavShowComponent,

      StatusComponent,
      ShowStatComponent,
      AddEditStatComponent,



      ComponentssComponent
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [SharedIntService],
  bootstrap: [AppComponent]
})
export class AppModule { }
