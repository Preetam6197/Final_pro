



import { Component, Input, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SharedIntService } from '../shared/sharedInt.service';

@Component({
  selector: 'app-RegisterInt',
  templateUrl: './RegisterInt.component.html',
  styleUrls: ['./RegisterInt.component.css']
})
export class RegisterIntComponent implements OnInit {

  constructor(public ser: SharedIntService,private route: Router) { }

  ngOnInit() {
  }

  subReg(frm: NgForm) {
    if (this.ser.inD.regIntId== 0)
      this.insRegi(frm);
    else
    //this.insRegi(frm);
    alert("Registered Failsed");

      //alert("Please enter the details for registration");
  }

  insRegi(frm:NgForm)
  {
     this.ser.regSav().subscribe(a=>
      {
        alert("Registered Succeffuly");
        console.log(a);

     this.route.navigate(['/LoginInt']);

    });
  }



}
