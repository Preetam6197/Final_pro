import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Intern } from './Intern.model';

@Injectable({
  providedIn: 'root'
})
export class SharedIntService {

readonly Inturl="https://localhost:44395/api";

inReg:string='https://localhost:44395/api/RegInts';

inRl:string='https://localhost:44395/api/InternRL';
constructor(private hpt:HttpClient) { }
inD:Intern=new Intern();

//for registering intern account

regSav()
{
  return this.hpt.post(this.inReg,this.inD);
}




// foro Intern Recorddds
IntRecLst():Observable<any[]>{
  return this.hpt.get<any>(this.Inturl+'/IntRecs');
}

addIntRec(val:any){
  return this.hpt.post(this.Inturl+'/IntRecs',val);
}

updIntRec(val:any){
  return this.hpt.put(this.Inturl+`/IntRecs/${val.recId}`,val);
}

delInt(val:any){
  return this.hpt.delete(this.Inturl+'/IntRecs/'+val);
}



//Crud for designation of intern

desgDelete(val:any){
  return this.hpt.delete(this.Inturl+'/IntDesgs/'+val);
}


desgList():Observable<any[]>{
  return this.hpt.get<any>(this.Inturl+'/IntDesgs');
}

desgAdd(val:any){
  return this.hpt.post(this.Inturl+'/IntDesgs',val);
}
//changed update
desgUpdate(val:any){
  return this.hpt.put(this.Inturl+`/IntDesgs/${val.desgId}`,val);
}





//crud for working hours

whrDelete(val:any){
  return this.hpt.delete(this.Inturl+'/IntWhrs/'+val);
}


whrList():Observable<any[]>{
  return this.hpt.get<any>(this.Inturl+'/IntWhrs');
}

whrAdd(val:any){
  return this.hpt.post(this.Inturl+'/IntWhrs',val);
}
//changed update
whrUpdate(val:any){
  return this.hpt.put(this.Inturl+`/IntWhrs/${val.hId}`,val);
}


//crud for Request Leasves

lrDelete(val:any){
  return this.hpt.delete(this.Inturl+'/IntReqls/'+val);
}


lrList():Observable<any[]>{
  return this.hpt.get<any>(this.Inturl+'/IntReqls');
}

lrAdd(val:any){
  return this.hpt.post(this.Inturl+'/IntReqls',val);
}
//changed update
lrUpdate(val:any){
  return this.hpt.put(this.Inturl+`/IntReqls/${val.lId}`,val);
}

//crud for status
sDelete(val:any){
  return this.hpt.delete(this.Inturl+'/IntStats/'+val);
}


sAdd(val:any){
  return this.hpt.post(this.Inturl+'/IntStats',val);
}

sUpdate(val:any){
  return this.hpt.put(this.Inturl+`/IntStats/${val.sId}`,val);
}


sList():Observable<any[]>{
  return this.hpt.get<any>(this.Inturl+'/IntStats');
}

// sGetById(val:any){
//   return this.hpt.get(this.Inturl+'/IntStats/'+val.sId);
// }
sGetById(id:number){
  return this.hpt.get(this.Inturl+'/IntStats/'+id);
}











}
