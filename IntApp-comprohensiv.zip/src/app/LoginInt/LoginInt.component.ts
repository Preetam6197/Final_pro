import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SharedIntService } from '../shared/sharedInt.service';
import { LoginService } from './Login.service';

@Component({
  selector: 'app-LoginInt',
  templateUrl: './LoginInt.component.html',
  styleUrls: ['./LoginInt.component.css']
})
export class LoginIntComponent implements OnInit {

  constructor( public logs: LoginService, private route: Router) { }

  ngOnInit() {

  }



  logInt(mfr:NgForm){

    this.logs.IntLogin().subscribe(b=> {

      console.log("response from login",b);
      if(b==true){
        // localStorage.setItem('token',d.token)
        localStorage.setItem('token',"mkoplk");
        this.route.navigate(['/Compontss']);
      }
      else{
        alert(" Login failed  or  The user is not registered");
      }


     });
    }

    //for token n all





}

// console.log("login",this.user.value);
    // this.logs.IntLogin(this.user.value).subscribe(response=>{
    //   console.log("response from login",response);
    //   if(response == true){
    //     // this.route.navigate(['/Services',this.user.value.email]);
    //     this.route.navigate(['/Services']);
    //   }else{
    //     console.log("login failed",response);
    //   }
    // });

