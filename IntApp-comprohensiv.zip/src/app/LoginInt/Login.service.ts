import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Login } from './Login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  logurl:string='https://localhost:44395/api/InternRL'

constructor(private hpt:HttpClient) { }
logD:Login=new Login();

//for loggin the intern
// IntLogin(body: any): Observable<any>{
//   return this.hpt.post(this.logurl, body);

// }

IntLogin()
{
  return this.hpt.post(this.logurl,this.logD);
}

}
