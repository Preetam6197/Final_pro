/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { InternerComponent } from './Interner.component';

describe('InternerComponent', () => {
  let component: InternerComponent;
  let fixture: ComponentFixture<InternerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InternerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InternerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
