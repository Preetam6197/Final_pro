import { Component, Input, OnInit } from '@angular/core';
import { SharedIntService } from 'src/app/shared/sharedInt.service';

@Component({
  selector: 'app-int-add-edit',
  templateUrl: './int-add-edit.component.html',
  styleUrls: ['./int-add-edit.component.css']
})
export class IntAddEditComponent implements OnInit {

  constructor(private service:SharedIntService) { }

  @Input() int:any;
  //c
  recId:number=0;
  recName:string="";
  recEmail:string="";
  recPhn:string="";
  recAdd:string="";
  recStatus:string="";


  ngOnInit(): void {
    this.recId=this.int.recId;
    this.recName=this.int.recName;
    this.recEmail=this.int.recEmail;
    this.recPhn=this.int.recPhn;
    this.recAdd=this.int.recAdd;
    this.recStatus=this.int.recStatus;

  }

  addInternDet(){
    var val = {recId:this.recId,
      recName:this.recName,
    recEmail:this.recEmail,
  recPhn:this.recPhn,

  recAdd:this.recAdd,
  recStatus:this.recStatus

};
    this.service.addIntRec(val).subscribe(res=>{
      alert("Row is added succesffuly");
    });
  }

  updInternDet(){
    var val = {recId:this.recId,
      recName:this.recName,
    recEmail:this.recEmail,
  recPhn:this.recPhn,
  recAdd:this.recAdd,
  recStatus:this.recStatus};
    this.service.updIntRec(val).subscribe(res=>{
       alert("Updated Succesfuuly");
      
    });
  }

}
