import { Component, OnInit } from '@angular/core';
import { SharedIntService } from 'src/app/shared/sharedInt.service';

@Component({
  selector: 'app-hr-show',
  templateUrl: './hr-show.component.html',
  styleUrls: ['./hr-show.component.css']
})
export class HrShowComponent implements OnInit {

  constructor(private service:SharedIntService) { }


  internLst:any=[];


  Message:string="";
  addeditIntbool:boolean=false;
  int:any;



  ngOnInit(): void {

    //c

    this.intRefrsh();
  }

  InAClick(){
    this.int={
      //c
      hId:0,
      cHr:null,
      iHr:null

    }
    this.Message="PLease Enter the Below Details";
    this.addeditIntbool=true;

  }
//for editing u clickks


  InEClick(item:any){
    this.int=item;
    this.Message="Edit the below Details ";
    this.addeditIntbool=true;
  }
//here also for deleteimg
  InDClick(item:any){
    if(confirm('You want to delete ,,,Are you sure??')){
      //this.addeditIntbool=false;

      this.service.whrDelete(item.hId).subscribe(data=>{
        //ch
        //
        alert("the row is deleted successfully");
        this.intRefrsh();

        //c

        //this.intRefrsh();
      })
    }
  }

  close(){
    this.addeditIntbool=false;
    this.intRefrsh();
  }


  intRefrsh(){
    this.service.whrList().subscribe(data=>{
      this.internLst=data;

    });
  }

}
