import { Component, Input, OnInit } from '@angular/core';
import { SharedIntService } from 'src/app/shared/sharedInt.service';

@Component({
  selector: 'app-hr-add-edit',
  templateUrl: './hr-add-edit.component.html',
  styleUrls: ['./hr-add-edit.component.css']
})
export class HrAddEditComponent implements OnInit {

  constructor(private service:SharedIntService) { }
  @Input() int:any;

  //c
  hId:number=0;
  cHr:string="";
  iHr:string="";


  ngOnInit(): void {
    this.hId=this.int.hId;
    this.cHr=this.int.cHr;
    this.iHr=this.int.iHr;


  }

  addIHr(){
    var val = {hId:this.hId,
      cHr:this.cHr,
    iHr:this.iHr
  };
    this.service.whrAdd(val).subscribe(res=>{
      alert("Row is added succesffuly");
    });
  }

  updIHr(){
    var val = {hId:this.hId,
      cHr:this.cHr,
    iHr:this.iHr
  };
    this.service.whrUpdate(val).subscribe(res=>{
       alert("Updated Succesfuuly");
      //
    });
  }

}
