import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-IntDesg',
  templateUrl: './IntDesg.component.html',
  styleUrls: ['./IntDesg.component.css']
})
export class IntDesgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
