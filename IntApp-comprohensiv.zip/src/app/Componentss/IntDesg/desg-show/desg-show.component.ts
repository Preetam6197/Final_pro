import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { SharedIntService } from 'src/app/shared/sharedInt.service';

@Component({
  selector: 'app-desg-show',
  templateUrl: './desg-show.component.html',
  styleUrls: ['./desg-show.component.css']
})
export class DesgShowComponent implements OnInit {

  constructor(private service:SharedIntService) { }



  internLst:any=[];

//intilixze
  Message:string="";
  addeditIntbool:boolean=false;
  int:any;



  ngOnInit(): void {


    this.intRefrsh();
  }

  InAClick(){
    this.int={
      //ini
      desgId:0,
      desgName:null,
      desgRole:null,
      depName:null
    }
    this.Message="PLease Enter the Below Details";
    this.addeditIntbool=true;

  }

  InEClick(item:any){
    this.int=item;
    this.Message="Edit the below Details ";
    this.addeditIntbool=true;
  }
//her
  InDClick(item:any){
    if(confirm('You want to delete ,,,Are you sure??')){
      //this.addeditIntbool=false;

      this.service.desgDelete(item.desgId).subscribe(data=>{
        //ch
        //
        alert("The row is deleted successfully");
        this.intRefrsh();

        //c

        //this.intRefrsh();
      })
    }
  }

  close(){
    this.addeditIntbool=false;
    this.intRefrsh();
  }


  intRefrsh(){
    this.service.desgList().subscribe(data=>{
      this.internLst=data;
      //c

    });
  }

  // FilterFn(){
  //   var DepartmentIdFilter = this.DepartmentIdFilter;
  //   var DepartmentNameFilter = this.DepartmentNameFilter;

  //   this.internLst = this.DepartmentListWithoutFilter.filter(function (el){
  //       return el.DepartmentId.toString().toLowerCase().includes(
  //         DepartmentIdFilter.toString().trim().toLowerCase()
  //       )&&
  //       el.DepartmentName.toString().toLowerCase().includes(
  //         DepartmentNameFilter.toString().trim().toLowerCase()
  //       )
  //   });
  // }


}
