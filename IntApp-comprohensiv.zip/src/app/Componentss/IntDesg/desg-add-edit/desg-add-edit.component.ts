import { Component, Input, OnInit } from '@angular/core';
import { SharedIntService } from 'src/app/shared/sharedInt.service';

@Component({
  selector: 'app-desg-add-edit',
  templateUrl: './desg-add-edit.component.html',
  styleUrls: ['./desg-add-edit.component.css']
})
export class DesgAddEditComponent implements OnInit {

  constructor(private service:SharedIntService) { }

  @Input() int:any;
  //initilaizing
  desgId:number=0;
  desgName:string="";
  desgRole:string="";
  depName:string="";

  ngOnInit(): void {
    this.desgId=this.int.desgId;
    this.desgName=this.int.desgName;
    this.desgRole=this.int.desgRole;
    this.depName=this.int.depName;

  }

  addDesgDet(){
    var val = {desgId:this.desgId,
      desgName:this.desgName,
    desgRole:this.desgRole,
  depName:this.depName};
    this.service.desgAdd(val).subscribe(res=>{
      alert("Row is added succesffuly");
    });
  }

  updInternDesgtn(){
    var val = {desgId:this.desgId,
      desgName:this.desgName,
    desgRole:this.desgRole,
  depName:this.depName};
    this.service.desgUpdate(val).subscribe(res=>{
       alert("Updated Succesfuuly");
      //console.log(res);
    });
  }

}
