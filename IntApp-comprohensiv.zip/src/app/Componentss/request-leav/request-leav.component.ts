import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-leav',
  templateUrl: './request-leav.component.html',
  styleUrls: ['./request-leav.component.css']
})
export class RequestLeavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
