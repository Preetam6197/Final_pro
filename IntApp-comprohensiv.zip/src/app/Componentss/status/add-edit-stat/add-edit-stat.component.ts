import { Component, Input, OnInit } from '@angular/core';
import { SharedIntService } from 'src/app/shared/sharedInt.service';

@Component({
  selector: 'app-add-edit-stat',
  templateUrl: './add-edit-stat.component.html',
  styleUrls: ['./add-edit-stat.component.css']
})
export class AddEditStatComponent implements OnInit {

  constructor(private service:SharedIntService) { }
  @Input() int:any;

  sId:number=0;
  intId:string="";



  ngOnInit(): void {
    this.sId=this.int.sId;
    this.intId=this.int.intId;



  }

  statAdd(){
    var val = {sId:this.sId,
      intId:this.intId
  };
    this.service.sAdd(val).subscribe(res=>{
      alert("Row is added succesffuly");
    });
  }

  updStat(){
    var val = {sId:this.sId,
      intId:this.intId
  };
    this.service.sUpdate(val).subscribe(res=>{
       alert("Updated Succesfuuly");

    });
  }

}
