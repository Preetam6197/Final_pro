import { Component, OnInit } from '@angular/core';
import { AuthService } from '../shared/auth.service';

@Component({
  selector: 'app-Componentss',
  templateUrl: './Componentss.component.html',
  styleUrls: ['./Componentss.component.css']
})
export class ComponentssComponent implements OnInit {

  constructor(private a:AuthService) { }

  ngOnInit() {
  }
  gh(){
    this.a.remlog();
  }

  onlogout(event:Event){
    window.localStorage.clear();

   localStorage.clear();
   event.preventDefault();
    localStorage.removeItem("mkoplk");
    //localStorage.removeItem(key);
    window.localStorage.clear();
    this.a.logout();

  }

}
