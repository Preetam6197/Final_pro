import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ComponentssComponent } from './Componentss/Componentss.component';
import { IntDesgComponent } from './Componentss/IntDesg/IntDesg.component';
import { InternerComponent } from './Componentss/Interner/Interner.component';
import { RequestLeavComponent } from './Componentss/request-leav/request-leav.component';
import { StatusComponent } from './Componentss/status/status.component';
import { WorkIntHrComponent } from './Componentss/work-int-hr/work-int-hr.component';

import { LoginIntComponent } from './LoginInt/LoginInt.component';
import { RegisterIntComponent } from './RegisterInt/RegisterInt.component';
import { AuthGuard } from './shared/auth.guard';

const routes: Routes = [


  {path:'',component:LoginIntComponent},
  {path:'RegisterInt',component:RegisterIntComponent},
  {path:'LoginInt',component:LoginIntComponent},
  {path:'Compontss',component:ComponentssComponent,canActivate:[AuthGuard]},
  {path:'Compontss/Desgs',component:IntDesgComponent,canActivate:[AuthGuard]},
  {path:'Compontss/Ints',component:InternerComponent,canActivate:[AuthGuard]},
  {path:'Compontss/Hours',component:WorkIntHrComponent,canActivate:[AuthGuard]},
  {path:'Compontss/Leaves',component:RequestLeavComponent,canActivate:[AuthGuard]},
  {path:'Compontss/Status',component:StatusComponent,canActivate:[AuthGuard]},






];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
