/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { SharedIntService } from './sharedInt.service';

describe('Service: SharedInt', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SharedIntService]
    });
  });

  it('should ...', inject([SharedIntService], (service: SharedIntService) => {
    expect(service).toBeTruthy();
  }));
});
