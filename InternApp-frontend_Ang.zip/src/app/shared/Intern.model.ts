export class Intern {

  regIntId:number=0;
  intName:string='';
  intEmail: string='';
  intPas: string='';
  intNu: string='';
  intAge: string='';
  intCity: string='';
  intAddr: string='';
}

