/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { LoginIntComponent } from './LoginInt.component';

describe('LoginIntComponent', () => {
  let component: LoginIntComponent;
  let fixture: ComponentFixture<LoginIntComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginIntComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginIntComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
//mod
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
