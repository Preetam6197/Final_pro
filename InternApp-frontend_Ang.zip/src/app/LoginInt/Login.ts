export class Login {
  logEmail:string='';
  logPas:string='';
}
