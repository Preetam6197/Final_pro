import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work-int-hr',
  templateUrl: './work-int-hr.component.html',
  styleUrls: ['./work-int-hr.component.css']
})
export class WorkIntHrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
