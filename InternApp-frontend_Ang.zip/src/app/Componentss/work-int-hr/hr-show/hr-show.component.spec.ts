/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { HrShowComponent } from './hr-show.component';

describe('HrShowComponent', () => {
  let component: HrShowComponent;
  let fixture: ComponentFixture<HrShowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrShowComponent ]
    })
    .compileComponents();
  }));
//mod
  beforeEach(() => {
    fixture = TestBed.createComponent(HrShowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
