import { Component, Input, OnInit } from '@angular/core';
import { SharedIntService } from 'src/app/shared/sharedInt.service';

@Component({
  selector: 'app-leav-add-edit',
  templateUrl: './leav-add-edit.component.html',
  styleUrls: ['./leav-add-edit.component.css']
})
export class LeavAddEditComponent implements OnInit {

  constructor(private service:SharedIntService) { }
  @Input() int:any;
  //c
  lId:number=0;
  lType:string="";
  lReason:string="";


  ngOnInit(): void {
    this.lId=this.int.lId;
    this.lType=this.int.lType;
    this.lReason=this.int.lReason;


  }

  LeaveAdd(){
    var val = {lId:this.lId,
      lType:this.lType,
    lReason:this.lReason
  };
    this.service.lrAdd(val).subscribe(res=>{
      alert("Row is added succesffuly");
    });
  }


  updLeavee(){
    var val = {lId:this.lId,
      lType:this.lType,
    lReason:this.lReason
  };
    this.service.lrUpdate(val).subscribe(res=>{
       alert("Updated Succesfuuly");

    });
  }

}
