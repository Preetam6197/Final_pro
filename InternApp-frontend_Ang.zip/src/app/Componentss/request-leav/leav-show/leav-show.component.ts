import { Component, OnInit } from '@angular/core';
import { SharedIntService } from 'src/app/shared/sharedInt.service';

@Component({
  selector: 'app-leav-show',
  templateUrl: './leav-show.component.html',
  styleUrls: ['./leav-show.component.css']
})
export class LeavShowComponent implements OnInit {

  constructor(private service:SharedIntService) { }


  internLst:any=[];


  Message:string="";
  addeditIntbool:boolean=false;
  int:any;



  ngOnInit(): void {

    //c

   //
    this.intRefrsh();
  }

  InAClick(){
    this.int={
      //c
      lId:0,
      lType:null,
      lReason:null

    }
    this.Message="PLease Enter the Below Details";
    this.addeditIntbool=true;

  }
//hediting
  InEClick(item:any){
    this.int=item;
    this.Message="Edit the below Details ";
    this.addeditIntbool=true;
  }
//hdeleting
  InDClick(item:any){
    if(confirm('You want to delete ,,,Are you sure??')){
      //this.addeditIntbool=false;

      this.service.lrDelete(item.lId).subscribe(data=>{
        //ch
        //
        alert("The row/Data is deleted successfully");
        this.intRefrsh();

        //c

        //this.intRefrsh();
      })
    }
  }

  close(){
    this.addeditIntbool=false;
    this.intRefrsh();
  }


  intRefrsh(){
    this.service.lrList().subscribe(data=>{
      this.internLst=data;

    });
  }

}
