import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Interner',
  templateUrl: './Interner.component.html',
  styleUrls: ['./Interner.component.css']
})
export class InternerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
