/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { IntShowComponent } from './int-show.component';

describe('IntShowComponent', () => {
  let component: IntShowComponent;
  let fixture: ComponentFixture<IntShowComponent>;
//mod
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntShowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntShowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
