import { Component, OnInit } from '@angular/core';
import { SharedIntService } from 'src/app/shared/sharedInt.service';

@Component({
  selector: 'app-int-show',
  templateUrl: './int-show.component.html',
  styleUrls: ['./int-show.component.css']
})
export class IntShowComponent implements OnInit {

  constructor(private service:SharedIntService) { }
  internLst:any=[];


    Message:string="";
    addeditIntbool:boolean=false;
    int:any;
  ngOnInit() {
    this.intRefrsh();
  }

  InAClick(){
    this.int={
      //c
      recId:0,
      recName:null,
      recEmail:null,
      recPhn:null,
      recAdd:null,
      recStatus:null

    }
    this.Message="PLease Enter ksjbakthe Below Details";
    this.addeditIntbool=true;

  }

  //edit internn
  InEClick(item:any){
    this.int=item;
    this.Message="Edit the below Details ";
    this.addeditIntbool=true;
  }

  InDClick(item:any){
    if(confirm('You want to delete ,,,Are you sure??')){
      //this.addeditIntbool=false;

      this.service.delInt(item.recId).subscribe(data=>{
        //ch
        //
        alert("The row/data is deleted successfully");
        this.intRefrsh();

        //c

        //this.intRefrsh();
      })
    }
  }

  close(){
    this.addeditIntbool=false;
    this.intRefrsh();
  }


  intRefrsh(){
    this.service.IntRecLst().subscribe(data=>{
      this.internLst=data;
      //
    });
  }

}
