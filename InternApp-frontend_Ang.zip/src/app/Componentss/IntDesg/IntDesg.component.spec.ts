/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { IntDesgComponent } from './IntDesg.component';
describe('IntDesgComponent', () => {
  let component: IntDesgComponent;
  let fixture: ComponentFixture<IntDesgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntDesgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntDesgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
