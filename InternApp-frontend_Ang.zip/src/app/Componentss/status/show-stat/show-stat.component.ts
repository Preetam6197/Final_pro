import { Component, Input, OnInit } from '@angular/core';
import { SharedIntService } from 'src/app/shared/sharedInt.service';

@Component({
  selector: 'app-show-stat',
  templateUrl: './show-stat.component.html',
  styleUrls: ['./show-stat.component.css']
})
export class ShowStatComponent implements OnInit {



constructor(private service:SharedIntService) { }
  internLst:any=[];

  //H
    Message:string="";
    addeditIntbool:boolean=false;
    int:any;

    DepartmentIdFilter:string="";
    DepartmentNameFilter:string="";
    DepartmentListWithoutFilter:any=[];
  ngOnInit() {
    this.intRefrsh();
  }

  InAClick(){
    this.int={
      //c
      recId:0,
      recName:null,
      recEmail:null,
      recPhn:null,
      recAdd:null,
      recStatus:null

    }
    this.Message="PLease Enter ksjbakthe Below Details";
    this.addeditIntbool=true;

  }

  //for edoit
  InEClick(item:any){
    this.int=item;
    this.Message="Edit the below Details ";
    this.addeditIntbool=true;
  }
//for delete
  InDClick(item:any){
    if(confirm('Are you sure??')){
      //this.addeditIntbool=false;

      this.service.delInt(item.recId).subscribe(data=>{
        //ch
        //alert(data.toString());
        alert("deleted successfully");
        this.intRefrsh();

        //c

        //this.intRefrsh();
      })
    }
  }

  close(){
    this.addeditIntbool=false;
    this.intRefrsh();
  }


  intRefrsh(){
    this.service.IntRecLst().subscribe(data=>{
      this.internLst=data;

    });
  }



}

